import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import javax.swing.JFrame;   
import javax.swing.Timer;
import java.awt.Toolkit;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.ImageObserver;

public class Jogo extends JFrame 
{
	private Image Nave[];
	private Image Inimigo[];
	private Image Tiro;		
	
	private Timer tempo;
	private int i = 0;	
	private int pos_tiro_x = 0;
	private int pos_tiro_y = 0;	
	private boolean ativa_tiro = false;	

	int x1=230,
	x2=20,
	y1=400,
	y2=20;	

	public Jogo()
	{		
		super("Jogo de nave");
		
		setFocusable(true);
		requestFocusInWindow();

		Nave = new Image[4];
		Inimigo = new Image[4];			

		//Muda a cor de fundo para preto		
		getContentPane().setBackground(Color.black);

		Nave[0] = Toolkit.getDefaultToolkit().getImage("nav_0.JPG");
		Nave[1] = Toolkit.getDefaultToolkit().getImage("nav_1.JPG");
		Nave[2] = Toolkit.getDefaultToolkit().getImage("nav_2.JPG");
		Nave[3] = Toolkit.getDefaultToolkit().getImage("nav_3.JPG");
		
		Inimigo[0] = Toolkit.getDefaultToolkit().getImage("inimiga_0.JPG");
		Inimigo[1] = Toolkit.getDefaultToolkit().getImage("inimiga_1.JPG");
		Inimigo[2] = Toolkit.getDefaultToolkit().getImage("inimiga_2.JPG");
		Inimigo[3] = Toolkit.getDefaultToolkit().getImage("inimiga_3.JPG");		
		
		Tiro = Toolkit.getDefaultToolkit().getImage("fogo.JPG");		

		//Muda o tamanho da janela
		setSize(510,510); 

		//Deixa a janela visivel
		setVisible(true);    	

		addKeyListener
		(
				new KeyListener()
				{   
					//M�todo disparado assim que pressiona a tecla
					public void keyPressed(KeyEvent a)
					{   
						int code = a.getKeyCode();
						switch(code)
						{

                        //Ativa o Tiro	
						case 32:
							ativa_tiro = true;	
							pos_tiro_x = x1+15;
							pos_tiro_y = y1; 							
							repaint();
							break;		

						//Move o objeto para esquerda	
						case 37:
							if(x1!=40)
							{
								x1=x1-10;						
								repaint();
							}
							else
								repaint();
							
							break;		

							//Move o objeto para cima	
						case 38:
							if(y1!=60)
							{
								y1=y1-10;
								repaint();
							}
							else
								repaint();								
							break;					

							//Move o objeto para direita
						case 39:

							if(x1!=420)
							{
								//muda a posi��o X do quadrado na tela
								x1=x1+10;						
								repaint();
							}
							else
								repaint();
							break;

							//Move o objeto para baixo
						case 40:
							if(y1!=400)
							{
								y1=y1+10;
								repaint();
							}
							else
								repaint();
							break;

						default:
							System.out.println("Codigo da Tecla �:" + code);
						break;
						}
					}   
					public void keyTyped(KeyEvent b) { }   

					//M�todo disparado assim que solta a tecla            
					public void keyReleased(KeyEvent e) { }   
				});
	}

	public void paint(Graphics fundo)
	{
		int mt_x[] = {0, 510, 510, 0, 0, 25, 480, 480, 255, 25, 25};
		int mt_y[] = {29, 29, 510, 510, 29, 50, 50, 480, 450, 480, 50};
		
		
		fundo.setColor(Color.GRAY);

		super.paint(fundo);

		if (pos_tiro_y <= 10)
		   ativa_tiro = false;
			   
		//tiro
		if (ativa_tiro == true )
		{
			pos_tiro_y-=10; 
		   fundo.drawImage(Tiro, pos_tiro_x, pos_tiro_y, 20, 20, this);
		}
				
		fundo.fillPolygon(mt_x,mt_y,11);
		
		

				int a;
		        //Lan�a o fogo
				for(a = 0; a <= 3; a++)
				{
					
					fundo.drawImage(Nave[a], x1, y1, 50, 50, (ImageObserver) this);
		            //desenha nave inimiga			
					fundo.drawImage(Inimigo[a], 100, 50, 50, 50, (ImageObserver) this);			
					
					try 
					{
						Thread.sleep(10);
					} catch (InterruptedException e) 
					{			
						e.printStackTrace();
					}	
					
				}
				
				//Recolhe o fogo
				for(a = 3; a >= 0; a--)
				{
		            //desenha nave usu�rio
					fundo.drawImage(Nave[a], x1, y1, 50, 50, (ImageObserver) this);
		            //desenha nave inimiga			
					fundo.drawImage(Inimigo[a], 100, 50, 50, 50, (ImageObserver) this);			
					
					try 
					{
						Thread.sleep(10);
					} catch (InterruptedException e) 
					{			
						e.printStackTrace();
				     }				
				}			

			
		
		
				
		repaint();
	}

	public static void main(String[] args) 
	{
		Jogo p = new Jogo();  
		p.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}