import java.util.Scanner;

public class Jogo 
{
	static String matriz[][] = new String[3][3];

	public static void computador()
	{
		boolean marcou;
		int cont;

		marcou = false;

		for (int i=0; i<= 2; i++)
		{
			if ((matriz[1][i] == "X") && (matriz[2][i] == "X") && (matriz[0][i] != "O") && (matriz[0][i] != "X") )
			{
				if (marcou == false )
				{
					marcou = true;
					entrada(i+1,"O");
				}    
			}        
		}

		for (int i=0; i<= 2; i++)
		{
			if ((matriz[0][i] == "X") && (matriz[2][i] == "X") && (matriz[1][i] != "O") && (matriz[1][i] != "X") )
			{
				if (marcou == false ) 
				{
					marcou = true;
					entrada(i+4,"O");
				}
			}
		}	

		for (int i=0; i<= 2; i++)
		{
			if ((matriz[0][i] == "X") && (matriz[1][i] == "X") && (matriz[2][i] != "O") && (matriz[2][i] != "X"))
				if (marcou == false )
				{
					marcou = true;
					entrada(i+7,"O");
				}	
		}

		cont = 1;

		for (int i=0; i<= 2; i++)
		{

			if ((matriz[i][1] == "X") && (matriz[i][2] == "X") && (matriz[i][0] != "O") && (matriz[i][0] != "X")  )
			{
				if (marcou == false )
				{
					marcou = true;
					entrada(cont,"O");
					cont += 3;
				}
			}	
		}

		cont = 2;

		for (int i=0; i<= 2; i++)
		{
			if ((matriz[i][0] == "X") &&  (matriz[i][2] == "X") &&  (matriz[i][1] != "O") &&  (matriz[i][1] != "X")  )
			{
				if (marcou == false )
				{
					marcou = true;
					entrada(cont,"O");
					cont += 3;
				}
			}
		}

		cont = 3;

		for (int i=0; i<= 2; i++)
		{
			if ((matriz[i][0] == "X") &&  (matriz[i][1] == "X") &&  (matriz[i][2] != "O") &&  (matriz[i][2] != "X")  )
			{
				if (marcou == false ) 
				{
					marcou = true;
					entrada(cont,"O");
					cont += 3;
				}
			}
		}


		//#cruzado
		if ((matriz[0][0] == "X") && (matriz[1][1] == "X") && (matriz[2][2] != "O") && (matriz[2][2] != "X") )
		{
			if (marcou == false )
			{
				marcou = true;
				entrada(9,"O");
			}
		}

		else if ((matriz[0][2] == "X") && (matriz[1][1] == "X") && (matriz[2][0] != "O") && (matriz[2][0] != "X") )
		{
			if (marcou == false )
			{
				marcou = true;
				entrada(7,"O");
			}
		}	

		else if ((matriz[2][0] == "X") && (matriz[1][1] == "X") && (matriz[0][2] != "O") && (matriz[0][2] != "X") )
		{
			if (marcou == false )
			{
				marcou = true;
				entrada(3,"O");
			}
		}
		else if  ((matriz[2][2] == "X") && (matriz[1][1] == "X") && (matriz[0][0] != "O") && (matriz[0][0] != "X") )
		{
			if (marcou == false ) 
			{
				marcou = true;
				entrada(1,"O");
			}
		}

		else if ((matriz[1][1] != "X") && (matriz[1][1] != "O"))
		{
			if (marcou == false ) 
			{
				marcou = true;
				entrada(5,"O");
			}
		}
		else if ((matriz[1][0] != "X") && (matriz[1][0] != "O"))
		{
			if (marcou == false ) 
			{
				marcou = true;
				entrada(4,"O");
			}
		}
		else if ((matriz[2][0] != "X") && (matriz[2][0] != "O"))
		{
			if (marcou == false )
			{
				marcou = true;
				entrada(7,"O");
			}
		}
		else if ((matriz[0][2] != "X") && (matriz[0][2] != "O"))
		{
			if (marcou == false )
			{
				marcou = true;
				entrada(3,"O");
			}
		}
		else if ((matriz[0][0] != "X") && (matriz[0][0] != "O"))
		{
			if (marcou == false )
			{
				marcou = true;
				entrada(1,"O");
			}
		}

		else if ((matriz[2][2] != "X") && (matriz[2][2] != "O"))
		{
			if (marcou == false )
			{
				marcou = true;
				entrada(9,"O");
			}
		}
		//#------
	}

	public static void entrada(int posicao, String marca)
	{
		switch (posicao)
		{
		case 1:
			matriz[0][0] = marca;
			break;
		case 2:
			matriz[0][1] = marca;
			break;
		case 3:	
			matriz[0][2] = marca;
			break;
		case 4:	
			matriz[1][0] = marca;
			break;
		case 5:
			matriz[1][1] = marca;
			break;
		case 6:
			matriz[1][2] = marca;
			break;
		case 7:
			matriz[2][0] = marca;
			break;
		case 8:
			matriz[2][1] = marca;
			break;
		case 9:
			matriz[2][2] = marca;
			break;
		}
	}

	public static void apresentar()
	{
		System.out.println("" + matriz[0][0] + "   |   " + matriz[0][1]+ "   |   " + matriz[0][2] + " ");
		System.out.println("--------------------");
		System.out.println("" + matriz[1][0] + "   |   " + matriz[1][1] + "   |   " + matriz[1][2] + " ");
		System.out.println("--------------------");
		System.out.println("" + matriz[2][0] + "   |   " + matriz[2][1] + "   |   " + matriz[2][2] + " ");
	}

	public static boolean ganhou(String g)
	{
		if (((matriz[0][0] == g) && (matriz[0][1] == g) && (matriz[0][2] == g)) || ((matriz[1][0] == g) && (matriz[1][1] == g) && (matriz[1][2] == g)) ||      ((matriz[2][0] == g) && (matriz[2][1] == g) && (matriz[2][2] == g)) ||  ((matriz[0][0] == g) && (matriz[1][0] == g) && (matriz[2][0] == g)) || ((matriz[0][1] == g) && (matriz[1][1] == g) && (matriz[2][1] == g)) ||     ((matriz[0][2] == g) && (matriz[1][2] == g) && (matriz[2][2] == g)) ||  ((matriz[0][0] == g) && (matriz[1][1] == g) && (matriz[2][2] == g)) ||  ((matriz[2][0] == g) && (matriz[1][1] == g) && (matriz[0][2] == g)))
		{
			System.out.println(g + "Ganhou");
			return true;
		}	
		else
		{
			return false;
		}
	}

	public static void main(String[] args) 
	{
		boolean jogada = false;
		int cont = 1;
		int jogadas = 0;
		int posicao;

		for (int j=0; j<3; j++) 
		{
			for (int i=0; i<3; i++) 
			{
				matriz[j][i] = Integer.toString(cont);
				cont += 1;
			}
		}
		Scanner teclado = new Scanner(System.in);

		while (true)
		{
			apresentar();
			System.out.println("-=-=-=-=-=-=-=-=-=-=-=");
			if (jogada == false)
			{
				System.out.println("Digite a posi��o");
				posicao = teclado.nextInt();
				entrada(posicao, "X");
				jogada = true;
				if (ganhou("X"))
				{
					apresentar();
					break;
				}

			}else {
				computador();
				if (ganhou("O"))
				{
					apresentar();
					break;					
				}
				jogada = false;
			}
			jogadas+= 1;
			if (jogadas == 9)
			{
				System.out.println("Deu velha");
				break;
			}
		}
	}
}