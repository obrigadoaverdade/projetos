import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.Graphics; //importa a classe Graphics
import javax.swing.*; //importa todo o pacote swing
import java.awt.Image;
import java.awt.Toolkit;

public class sistemasolar extends JFrame
{
	private static final long serialVersionUID = 1L;
    private Image sol;
	private Image mercurio;
	private Image venus;
	private Image terra;
	private Image marte;
	private Image jupiter;
	private Image saturno;
	private Image urano;
	private Image netuno;
	int i;
	
	public static void main(String[] args){   
		//Cria um objeto p   
		sistemasolar p = new sistemasolar();   
		p.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  

		}
	
	public sistemasolar() {
		i = 0;
				
				sol = Toolkit.getDefaultToolkit().getImage("sol.jpg"); 
				mercurio = Toolkit.getDefaultToolkit().getImage("mercurio.jpg");
				venus = Toolkit.getDefaultToolkit().getImage("venus.jpg");
				terra = Toolkit.getDefaultToolkit().getImage("terra.jpg");

				
				marte = Toolkit.getDefaultToolkit().getImage("marte.jpg");
				
				jupiter = Toolkit.getDefaultToolkit().getImage("jupiter.jpg");
				saturno = Toolkit.getDefaultToolkit().getImage("saturno.jpg");
				urano = Toolkit.getDefaultToolkit().getImage("urano.jpg");
				netuno = Toolkit.getDefaultToolkit().getImage("netuno.jpg");
				
				getContentPane().setBackground( Color.black );
				setSize(1024,800); // Define o Tamanho do Frame como x = 1024 e y = 800
				
				setVisible(true);
				
			}	
	

	public void paint(Graphics g)
	{ 
		int x_merc,y_merc,dx_merc,dy_merc; //mercurio
		int x_ven,y_ven,dx_ven,dy_ven; //venus
		int x_terra, y_terra, dx_terra, dy_terra; //Terra
		int x_marte, y_marte, dx_marte, dy_marte; //marte
		int x_jup, y_jup, dx_jup, dy_jup; //Jupiter
		int x_sat, y_sat, dx_sat, dy_sat; //Saturno
		int x_ur, y_ur, dx_ur, dy_ur; //urano
		int x_net, y_net, dx_net, dy_net; //netuno
		
		
		int tam_merc;
		int tam_venus;
		int tam_terra;
		int tam_marte;
		int tam_jup;
		int tam_sat;
		int tam_ur;
		int tam_net;
		
		tam_merc = 100; //tamanho do raio da trajet�ria de merc�rio
		tam_venus = 130; //tamanho do raio da trajet�ria de Venus
		tam_terra = 165; //tamanho do raio da trajet�ria da Terra
		tam_marte = 205; // tamanho do raio da traget�ria de Marte
		tam_jup = 255; //tamanho do raio da traget�ria de Jupiter
		tam_sat = 305; // tamnho do raio da traget�ria de Saturno
		tam_ur = 305; // tamnho do raio da traget�ria de Urano
		tam_net = 305; // tamnho do raio da traget�ria de Urano
		
		final int posx = 500;
		
		dx_merc = posx; //posi��o x inicial do circulo de mercurio
		dx_ven = posx; //posi��o x inicial do circulo de Venus
		dx_terra = posx; //posi��o x inicial do circulo da Terra
		dx_marte = posx; //posi��o x inicial do circulo da marte
		dx_jup = posx; //posi��o x inicial do circulo da Jupiter
		dx_sat = posx; //posi��o x inicial do circulo de Saturno
		dx_ur = posx; //posi��o x inicial do circulo de urano
		dx_net = posx; //posi��o x inicial do circulo de urano
		
		final int posy = 350;
				
		dy_merc = posy;
		dy_ven = posy;
		dy_terra = posy;
		dy_marte = posy;
		dy_jup = posy;
		dy_sat = posy;
		dy_ur = posy;
		dy_net = posy;
		
		x_merc = 0; y_merc = 100; 
		x_ven = 0; y_ven = 100; 
		x_terra = 0; y_terra = 100;
		x_marte = 0; y_marte =  100;
		x_jup = 0; y_jup = 100;
		x_sat = 0; y_sat = 100;
		x_ur = 0; y_ur = 100;
		x_net = 0; y_net = 100;
		
//		chama a ver�o herdada do m�todo paint
		super.paint(g);


		for(; i <= 360; i++) //360*2=720, ou seja, vai dar 2 voltas
		{ 

			g.setColor(Color.YELLOW); //seleciona a cor amarela do nome do sol			
			g.setFont(new Font("Garamond", Font.BOLD, 12) );
			g.drawString("Sol", 500, 290);
			g.drawString("Sistema Solar", 10, 200);			
			
//			Planeta Merc�rio----------------- 

//			Cor da trajet�ria
			g.setColor(Color.white);

//			Trajet�ria
			g.drawOval(350,260,300,200);

//			C�lculo do movimento
			x_merc = (int)(Math.sin((3.14 * (i+10))/180 )* tam_merc*1.5);
			y_merc = (int)(Math.cos((3.14 * (i+10))/180 )* tam_merc);

//			Cor do nome do planeta vermelha
			g.setColor(Color.red);
//			Imagem do planeta mercurio 
			g.drawImage(marte,x_merc + dx_merc, y_merc + dy_merc,10,10,this);
//			Texto com o nome do planeta
			g.drawString("Merc�rio", x_merc + dx_merc, y_merc + dy_merc); 
			

//			-------

			
//			Planeta V�nus-----------------
//			Cor da trajet�ria
			g.setColor(Color.white);

//			Trajet�ria
			g.drawOval(310,220,380,270);

//			C�lculo do movimento
			x_ven = (int)(Math.sin((3.14 * (i+50))/180 )* tam_venus*1.5);
			y_ven = (int)(Math.cos((3.14 * (i+50))/180 )* tam_venus);

//			Cor do planeta azul
			g.setColor(Color.yellow);
//			Desenho do planeta Venus 
			//g.fillOval(x_ven + dx_ven , y_ven + dy_ven ,20,20);
			g.drawImage(venus,x_ven + dx_ven , y_ven + dy_ven,20,20,this);
//			Texto com o nome do planeta
			g.drawString("V�nus", x_ven + dx_ven, y_ven + dy_ven); 
			
			
//			------- 

//			Planeta Terra-----------------

//			Cor da trajet�ria
			g.setColor(Color.white);

//			Trajet�ria
			g.drawOval(270,180,460,340);

//			C�lculo do movimento
			x_terra = (int)(Math.sin((3.14 * (i+70))/180 )* tam_terra*1.5);
			y_terra = (int)(Math.cos((3.14 * (i+70))/180 )* tam_terra);

			
//			Cor do planeta azul
			g.setColor(Color.blue);
//			Imagem do planeta Terra
			g.drawImage(terra,x_terra + dx_terra,y_terra + dy_terra,30,30,this);
//			Texto com o nome do planeta
			g.drawString("Terra", x_terra + dx_terra, y_terra + dy_terra); 
//			------- 
			
			
//			Planeta Marte-----------------

//			Cor da trajet�ria
			g.setColor(Color.white);

//			Trajet�ria
			g.drawOval(230,140,540,410);

//			C�lculo do movimento
			x_marte = (int)(Math.sin((3.14 * (i+100))/180 )* tam_marte*1.5);
			y_marte = (int)(Math.cos((3.14 * (i+100))/180 )* tam_marte);

//			Cor do planeta laranja
			g.setColor(Color.orange);
//			Desenho do planeta Marte
			//g.fillOval(x_marte + dx_marte , y_marte + dy_marte ,40,40);
			g.drawImage(marte,x_marte + dx_marte , y_marte + dy_marte ,30,30,this);
//			Texto com o nome do planeta
			g.drawString("Marte", x_marte + dx_marte, y_marte + dy_marte); 
//			------- 
//			

			//Planeta Jupiter-----------------

//			Cor da trajet�ria
			g.setColor(Color.white);

//			Trajet�ria
			g.drawOval(190,100,620,480);
			

//			C�lculo do movimento
			x_jup = (int)(Math.sin((3.14 * (i+150))/180 )* tam_jup * 1.5);
			y_jup = (int)(Math.cos((3.14 * (i+150))/180 )* tam_jup);

//			Cor do nome do planeta
			g.setColor(Color.gray);
//			Imagem do planeta Jupiter 
			//g.fillOval(x_marte + dx_marte , y_marte + dy_marte ,50,50);
			g.drawImage(jupiter,x_jup + dx_jup , y_jup + dy_jup ,70,70,this);
//			Texto com o nome do planeta
			g.drawString("J�piter", x_jup + dx_jup, y_jup + dy_jup); 
//			------- 
			
			
//			Planeta Saturno-----------------

//			Cor da trajet�ria
			g.setColor(Color.white);

//			Trajet�ria
			g.drawOval(150,60,700,550);
			

//			C�lculo do movimento
			x_sat = (int)(Math.sin((3.14 * (i+220))/180 )* tam_sat*1.5);
			y_sat = (int)(Math.cos((3.14 * (i+220))/180 )* tam_sat);

//			Cor do nome do planeta
			g.setColor(Color.gray);
//			Imagem do planeta Jupiter 
			g.drawImage(saturno,x_sat + dx_sat , y_sat + dy_sat ,60,60,this);
//			Texto com o nome do planeta
			g.drawString("Saturno", x_sat + dx_sat, y_sat + dy_sat); 
			
//			-------
		
			
//			Planeta Urano-----------------

//			Cor da trajet�ria
			g.setColor(Color.white);

//			Trajet�ria
			g.drawOval(110,20,780,620);
			

//			C�lculo do movimento
			x_ur = (int)(Math.sin((3.14 * (i+280))/180 )* tam_ur*1.5);
			y_ur = (int)(Math.cos((3.14 * (i+280))/180 )* tam_ur);

//			Cor do nome do planeta
			g.setColor(Color.blue);
//			Imagem do planeta Urano 
			g.drawImage(urano,x_ur + dx_ur , y_ur + dy_ur ,30,30,this);
//			Texto com o nome do planeta
			g.drawString("Urano", x_ur + dx_ur, y_ur + dy_ur); 


			
//			-------
			
//			Planeta Netuno-----------------

//			Cor da trajet�ria
			g.setColor(Color.white);

//			Trajet�ria
			g.drawOval(70,-20,860,690);
			

//			C�lculo do movimento
			x_net = (int)(Math.sin((3.14 * (i+280))/180 )* tam_net*1.5);
			y_net = (int)(Math.cos((3.14 * (i+280))/180 )* tam_net);

//			Cor do nome do planeta
			g.setColor(Color.red);
//			Imagem do planeta Urano 
			g.drawImage(netuno,x_net + dx_net , y_net + dy_net ,30,30,this);
//			Texto com o nome do planeta
			g.drawString("Netuno", x_net + dx_net, y_net + dy_net); 

			
			
//			Atrasa o tempo
			try
			{
				Thread.sleep(10);
			}
			catch(InterruptedException e){}
			
			g.drawImage(sol,485,295,130,130,this);//Carrega a imagem do sol com tamanho 130x130			
			
			if (i == 360)
				break;

//			Apaga o desenho do mercurio anterior
			g.setColor(Color.black);
			g.fillRect(x_merc + dx_merc , y_merc + dy_merc,10,10);
			g.drawString("Merc�rio", x_merc + dx_merc, y_merc + dy_merc);


//			Apaga o desenho do venus anterior
			g.setColor(Color.black);
			g.fillRect(x_ven + dx_ven , y_ven + dy_ven,20,20);
			g.drawString("V�nus", x_ven + dx_ven, y_ven + dy_ven);

			
//			Apaga o desenho da terra anterior
			g.setColor(Color.black);
			g.fillRect(x_terra + dx_terra , y_terra + dy_terra ,30,30);
			g.drawString("Terra", x_terra + dx_terra, y_terra + dy_terra);
			
//			Apaga o desenho de marte anterior
			g.setColor(Color.black);
			g.fillRect(x_marte + dx_marte , y_marte + dy_marte ,30,30);
			g.drawString("Marte", x_marte + dx_marte, y_marte + dy_marte);
			
//			Apaga o desenho de Jupiter anterior
			g.setColor(Color.black);
			g.fillRect(x_jup + dx_jup , y_jup + dy_jup ,70,70);
			g.drawString("J�piter", x_jup + dx_jup, y_jup + dy_jup);
			
//			Apaga o desenho de Saturno anterior
			g.setColor(Color.black);
			g.fillRect( x_sat + dx_sat , y_sat + dy_sat ,60,60);
			g.drawString("Saturno",  x_sat + dx_sat , y_sat + dy_sat);
			
//			Apaga o desenho de Urano anterior
			g.setColor(Color.black);
			g.fillRect( x_ur + dx_ur , y_ur + dy_ur ,30,30);
			g.drawString("Urano",  x_ur + dx_ur , y_ur + dy_ur);	
			
//			Apaga o desenho de Urano anterior
			g.setColor(Color.black);
			g.fillRect( x_net + dx_net , y_net + dy_net ,30,30);
			g.drawString("Netuno",  x_net + dx_net , y_net + dy_net);	

			
						
//			limpa a tela
			//g.clearRect(0, 0, getWidth(), getHeight());
		} //fim do for
	}
}
