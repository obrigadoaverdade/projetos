import sqlite3

class Banco():
    def __init__(self):
        self.conexao = sqlite3.connect("agenda.db")
        self.criarTabela()

    def criarTabela(self):
        c = self.conexao.cursor()

        c.execute("""Create table if not exists tbAgenda(
                     id integer primary key autoincrement,
                     nome text,
                     telefone text)""")
        self.conexao.commit()
        c.close()

