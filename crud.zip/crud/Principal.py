from agenda import Agenda
import gi

gi.require_version("Gtk", "3.0")
from gi.repository import Gtk

builder = Gtk.Builder()
builder.add_from_file("interface.glade")

class InterfaceAgenda():
    def __init__(self):
        self.nomeCaixa = builder.get_object("nomeCaixa")
        self.telefoneCaixa = builder.get_object("telefoneCaixa")
        self.lb_status = builder.get_object("lb_status")
        self.ag = Agenda()        
  
    def onDestroy(self, *args):
        Gtk.main_quit()

    def btnInserir(self, button):
        self.ag.nome = self.nomeCaixa.get_text()
        self.ag.telefone = self.telefoneCaixa.get_text()              
        self.lb_status.set_text(str(self.ag.inserir()))
        self.nomeCaixa.set_text("")
        self.telefoneCaixa.set_text("")              

    def btnAtualizar(self, button):
        self.ag.nome = self.nomeCaixa.get_text()
        self.ag.telefone = self.telefoneCaixa.get_text()              
        self.lb_status.set_text(str(self.ag.atualizar()))
        self.nomeCaixa.set_text("")
        self.telefoneCaixa.set_text("")              
        
        
    def btnApagar(self, button):
        self.ag.nome = self.nomeCaixa.get_text()
        self.ag.telefone = self.telefoneCaixa.get_text()              
        self.lb_status.set_text(str(self.ag.apagar(self.ag.id)))
        self.nomeCaixa.set_text("")
        self.telefoneCaixa.set_text("")

    def btnBuscar(self, button):
        self.ag.nome = self.nomeCaixa.get_text()
        self.lb_status.set_text(str(self.ag.buscar(self.ag.nome)))
        self.telefoneCaixa.set_text(self.ag.telefone)
        
        

builder.connect_signals(InterfaceAgenda())

window = builder.get_object("FrmAgenda")
window.show_all()

Gtk.main()
