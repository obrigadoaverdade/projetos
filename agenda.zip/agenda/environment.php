<?php

define("ENVIRONMENT", "off");
//define("ENVIRONMENT", "production");

