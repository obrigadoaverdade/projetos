<?php
global $config;
?>

<h1>Agenda</h1>
        <a class = "btn btn-default" style="width:85px" 
        href="<?php echo BASE_URL ?>agenda/cadastrar">Adicionar</a>

<div class="alfabeto" >
  <ul>
<?php $conta=0; $alterna=0; $cor = array('#CCC', '#AAA') ;?>    

<?php $cont=1; $mostrar=true; $letras; $temp=""?>
  <?php foreach($agenda as $key => $ag): ?>   
            <?php if(count($agenda) > 1) 
                  {
                        if ($key > 0) 
                        { 
                            $keyAnterior = $key - 1; 
                            $anterior = $agenda[$keyAnterior]; 
                            $atual = $agenda[$key]; 
                            if (substr($anterior['nome'], 0,1) == (substr($atual['nome'],0,1))) 
                              $mostrar=false;
                            else
                              $mostrar=true;      
                        }
                  }
            ?>

            <?php  
              if($mostrar==true)  
              {               
               echo "<a href='#";
               echo substr($ag['nome'],0,1); 
               echo "'>";

                ($conta %2==0) ? $alterna = 0 :$alterna = 1;

               echo "<li style= 'background-color: $cor[$alterna]' ; > " ;               


               echo "";
               echo substr($ag['nome'],0,1); 
               echo "</li>";
               echo "</a> " ;

               $conta++;
             }

             
             ?> 

  <?php endforeach; ?>
</ul>
</div>
 <br>
 <br>
 <br>



<?php $mostrar = true; ?>

<table class="table table-striped table-bordered table-hover">        
	<thead>
		<tr>
			<th width="2"><center>N</center></th>
			<th width="100" ><center>Nome</center></th>
			<th><center>Descrição</center></th>
           	<th><center>Telefone</center></th>				
           	<th><center>Ações</center></th>			           
		</tr>
	</thead>

	<?php foreach($agenda as $key => $ag): ?>   
            <?php

                  //comparar dois registros no array
                  if(count($agenda) > 1) 
                  {
                  	    if ($key > 0) 
                         { //compara se não é o primeiro item, pois este não terá item anterior
                         	$keyAnterior = $key - 1; //armazena o indice do registro anterior
                            $anterior = $agenda[$keyAnterior]; //pega o item anterior do array
                            $atual = $agenda[$key]; //pega o item anterior do array

                            //echo "VALOR ANTERIOR ". substr($anterior['nome'],0,1) .'<br>';
                            //echo "VALOR ATUAL: "  . substr($atual['nome'],0,1). '<br>';
                            if (substr($anterior['nome'], 0,1) == (substr($atual['nome'],0,1))) 
                            { //comparar os ids (esta comparação ocorre devido a regra solicitada)
                            	$mostrar=false;

                            }else
                            {
                            	$mostrar=true;      



                            }


                         }
                  }
                  
            ?>

            <?php  
              if($mostrar==true)  
              { 
                echo "<tr><td colspan=5 
                      style='width: 100%; 
                             background-color:#CCC;
                             padding:0;
                             font-size: 25px; ';
                          >
                      ";
                 
                 echo substr($ag['nome'], 0,1); 
                 echo "<a NAME='";
                 echo substr($ag['nome'], 0,1);  
                 echo "' ></a>";

                 //<a NAME = "P">DESTINO AQUI</a>
                 echo "</td></tr>";

                 $temp = $temp . '   ' . substr($ag['nome'], 0,1); 
              } 

             ?> 


                 
		<tr>

			<td width="2"><center><?php echo $cont++ ; ?></center></td>
			<td><?php echo utf8_encode($ag['nome']); ?></td>
			<td><?php echo utf8_encode($ag['descricao']); ?></td>
			<td><center><?php echo $ag['telefone']; ?></center></td>
			<td><center>
    		<a class = "btn btn-default" style="width:65px; margin-bottom: 3px;" href="<?php echo BASE_URL ?>agenda/editar/<?php echo $ag['id']; ?>">Editar</a>
			
       <a onclick="excluircampo(<?php echo $ag['id']; ?> );" class = "btn btn-default"  style="width:65px; margin-bottom: 3px;">Excluir</a>


      <script>
      function excluircampo(campo)
      {
         if (confirm("Tem certeza que deseja excluir?")) 
         {
            window.location.href = '<?php echo BASE_URL ?>' + 'agenda/excluir/' + campo;
            alert('Excluido com sucesso!');  
         }
      }
  
      </script>


      
		    </center>
        </td>
		</tr>
	<?php endforeach; ?>
</table>







<div class="alfabeto" >
  <ul>
<?php $conta=0; $alterna=0; $cor = array('#CCC', '#AAA') ;?>    

<?php $cont=1; $mostrar=true; $letras; $temp=""?>
  <?php foreach($agenda as $key => $ag): ?>   
            <?php if(count($agenda) > 1) 
                  {
                        if ($key > 0) 
                        { 
                            $keyAnterior = $key - 1; 
                            $anterior = $agenda[$keyAnterior]; 
                            $atual = $agenda[$key]; 
                            if (substr($anterior['nome'], 0,1) == (substr($atual['nome'],0,1))) 
                              $mostrar=false;
                            else
                              $mostrar=true;      
                        }
                  }
            ?>

            <?php  
              if($mostrar==true)  
              {               
               echo "<a href='#";
               echo substr($ag['nome'],0,1); 
               echo "'>";

                ($conta %2==0) ? $alterna = 0 :$alterna = 1;

               echo "<li style= 'background-color: $cor[$alterna]' ; > " ;               


               echo "";
               echo substr($ag['nome'],0,1); 
               echo "</li>";
               echo "</a> " ;

               $conta++;
             }

             
             ?> 

  <?php endforeach; ?>
</ul>
</div>
