
<html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cadastrar Telefone</title>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

  </head>
  <body> 
  
    <div class="container">
      <form method="POST" class="form-signin" style="max-width:300px;margin:auto">

        <h2 class="form-signin-heading">Cadastrar Telefone</h2>

        <?php if(isset($aviso) && !empty($aviso)): ?>
        <div class="alert alert-danger" role="alert">
          <?php echo $aviso; ?>
        </div>
        <?php endif; ?>

        <label for="nome" class="sr-only">Nome</label>
        <input type="text" name="nome" id="nome" class="form-control" placeholder="Nome" required autofocus><br/>

        <label for="descricao" class="sr-only">Descrição</label>
        <input type="text" name="descricao" id="descricao" class="form-control" placeholder="Descrição" ><br/>

        <label for="telefone" class="sr-only">Telefone</label>
        <input type="text" name="telefone" id=telefone class="form-control" placeholder="Telefone" required><br/>
      
        <button class="btn btn-lg btn-primary btn-block" type="submit" >Salvar</button>
      </form>

    </div>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.11/jquery.mask.min.js"></script>
    <script type="text/javascript"> $("#telefone").mask("(00) 00000-0000"); </script>    

    <script src="<?php echo BASE_URL ?>agenda/assets/js/bootstrap.min.js"></script>

  </body>
</html>

