﻿<!DOCTYPE html>
  <head>

  <title>Agenda</title>

  <link rel ="stylesheet" href="<?php echo BASE_URL ?>assets/css/template.css"   />
    <meta name="viewport" content="width=device-width, initial-scale=1" />


  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel ="stylesheet" href="<?php echo BASE_URL ?>assets/css/style.css"   />
    
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">





   <script type="text/javascript" src="<?php echo BASE_URL ?>assets/js/jquery-3.3.1.min.js" /></scipt>
   <script type="text/javascript" src="<?php echo BASE_URL ?>assets/js/bootstrap.min.js" /></script>
   <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  </head>
  <body>
  
  



  <!--<div class="container"> -->
        <?php $this->loadViewInTemplate($viewName, $viewData);  ?>  
  <!-- </div>     -->
   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="<?php echo BASE_URL ?>assets/js/bootstrap.min.js"></script>  
  </body>
</html>