<?php
class Agenda extends model
{
	public function getLista()
	{
		$array = array();
		
		$sql = "Select * from tbagenda order by nome";
		$sql = $this->db->query($sql);

		if ($sql->rowCount()>0)
		{
		    $array = $sql->fetchAll();

		}
	    return $array;
	}

	public function getDados($id)
	{
		$array = array();
		$sql = "Select * from tbagenda where id = '$id' ";
        $sql = $this->db->query($sql) ;

		if ($sql->rowCount()>0)
		{
		    $array = $sql->fetch();

		}

	    return $array;
	}

	public function cad($nome, $desc, $tel)
	{
		$sql = "insert into tbagenda set nome = '$nome', descricao='$desc', telefone='$tel' ";
		$sql = $this->db->query($sql) ;

		if ($sql->rowCount()>0)
		{
		    $array = $sql->fetch();

		}
	}

	public function editar($nome, $desc, $tel, $id)
	{ 
	   $sql = "update tbagenda set nome = '$nome', descricao='$desc', telefone='$tel' where id='$id' ";
		$sql = $this->db->query($sql) ;
    }

    public function excluir($id)
    {
    	$sql = "delete from tbagenda where id = '$id' ";
        $sql = $this->db->query($sql) ;
    }

}