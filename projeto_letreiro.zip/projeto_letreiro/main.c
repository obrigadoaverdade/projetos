#include<windows.h>
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include<time.h>

/*             0     1    2     3   4      5      6      7         8  */
typedef enum{BLACK,BLUE,GREEN,CYAN,RED,MAGENTA,BROWN,LIGHTGRAY,DARKGRAY,   /* nome das cores */
             LIGHTBLUE,LIGHTGREEN,LIGHTCYAN,LIGHTRED,LIGHTMAGENTA,YELLOW,WHITE} COLORS;
                /*  9         10         11        12        13         14    15 */

static int __BACKGROUND = 1/*BLACK*/;/*pode ser o numero ou o nome da cor*/
static int __FOREGROUND = LIGHTGRAY;

void textcolor (int letras, int fundo);
void posXY(int x, int y);
void HideCursor();

void letra_O(int x, int y, char s);
void letra_L(int x, int y, char s);
void letra_A(int x, int y, char s);

main()
{

    int cx=0,cy=10;
    char tecla='a';
    int maximo = 0;
    
    HideCursor();
 
 
 while(tecla!='s')
 { 
    while(tecla!='s'&&!(tecla=kbhit()))
    { 
		textcolor(2,0);
        
        letra_O(cx, cy, 219);
        letra_L(cx+5, cy, 219);
		letra_A(cx+10,cy, 219);
		
        Sleep(100);		
        letra_O(cx, cy, 32);
        letra_L(cx+5, cy, 32);
        letra_A(cx+10,cy, 32);
              
        if (cx == 0)
        maximo = 0;
        
        if (cx >= 70)
           maximo = 1;
           
        if (maximo == 1)   
         cx--;
        else		 
        cx++;
 	}
 }
 getch();
}


void textcolor (int letras, int fundo)
{/*para mudar a cor de fundo mude o background*/
    __FOREGROUND = letras;
    __BACKGROUND = fundo;
    SetConsoleTextAttribute (GetStdHandle (STD_OUTPUT_HANDLE),
    letras + (__BACKGROUND << 4));
}


void posXY(int x, int y)
{
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE),(COORD){x,y});
}
void HideCursor()
{
  CONSOLE_CURSOR_INFO cursor = {1, FALSE};
  SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor);
}
int som(int f)
{
    Beep(f,150);/* primeiro a frqu�ncia depois o tempo de dura��o do som */
    return 0;
}

void letra_A(int x, int y, char s){
	posXY(x,y);
	printf("%c%c%c%c", s,s,s,s);
	posXY(x,y+1);
	printf("%c  %c", s,s);
	posXY(x,y+2);
	printf("%c  %c", s,s);
	posXY(x,y+3);
	printf("%c%c%c%c", s,s,s,s);
	posXY(x,y+4);
	printf("%c  %c", s,s);
	posXY(x,y+5);
	printf("%c  %c", s,s);
}

void letra_O(int x, int y, char s){
	posXY(x,y);
	printf("%c%c%c%c", s,s,s,s);
	posXY(x,y+1);
	printf("%c  %c", s,s);
	posXY(x,y+2);
	printf("%c  %c", s,s);
	posXY(x,y+3);
	printf("%c  %c", s,s);
	posXY(x,y+4);
	printf("%c  %c", s,s);
	posXY(x,y+5);
	printf("%c%c%c%c", s,s,s,s);
}


void letra_L(int x, int y, char s){
	posXY(x,y);
	printf("%c", s);
	posXY(x,y+1);
	printf("%c",s);
	posXY(x,y+2);
	printf("%c", s);
	posXY(x,y+3);
	printf("%c", s);
	posXY(x,y+4);
	printf("%c", s);
	posXY(x,y+5);
	printf("%c%c%c%c", s,s,s,s);
}


