<?php
class Compromisso extends model
{
	public function getSemana($data)
	{
		$a = "";
		$sql = "Select compromisso from tbcompromissos where data= '$data' ";

		//$sql = " Select compromisso from tbcompromissos where data= '2019-01-14' and  diasemana='2 feira' and hora= '05:20:00' ";

		$sql = $this->db->query($sql);

		if ($sql->rowCount()>0)
		{
			$a = $sql->fetch();			
		}

		return $a;
	}

	public function getComp($data="", $semana="", $hora="", $hora2="")
	{
		$a = "";
		//$sql = "Select compromisso from tbcompromissos where data= '$data' ";

		//$sql = " Select compromisso from tbcompromissos where data= '2019-01-14' and  diasemana='2 feira' and hora= '05:20:00' ";
        //$sql = " Select compromisso from tbcompromissos where data= '2019-01-14' and  diasemana='2 feira' and hora= '$hora' ";

       $sql = "Select compromisso,cor from tbcompromissos 
               where 
                   data = '$data' and  
                   diasemana = '$semana' and 
                   (hora >= '$hora' and hora <= '$hora2')
               ";



		$sql = $this->db->query($sql);

		if ($sql->rowCount()>0)
		{
			
			$a = $sql->fetch();			
			//echo $a['compromisso'];
			//echo $a['cor'];
		return $a;	
		}


		
	}


	public function getCompId($data="", $semana="", $hora="", $hora2="")
	{
		$a = "";
		//$sql = "Select compromisso from tbcompromissos where data= '$data' ";

		//$sql = " Select compromisso from tbcompromissos where data= '2019-01-14' and  diasemana='2 feira' and hora= '05:20:00' ";
        //$sql = " Select compromisso from tbcompromissos where data= '2019-01-14' and  diasemana='2 feira' and hora= '$hora' ";

       $sql = "Select id from tbcompromissos 
               where 
                   data = '$data' and  
                   diasemana = '$semana' and 
                   (hora >= '$hora' and hora <= '$hora2')
               ";



		$sql = $this->db->query($sql);

		if ($sql->rowCount()>0)
		{
			
			$a = $sql->fetch();			
			//echo $a['compromisso'];
		return $a;	
		}


		
	}


	public function salvando($id, $compromisso,$dataAtual, $cor)
	{
		
		$diasemana1 = array('Domingo', '2 feira', '3 feira', '4 feira', '5 feira', '6 feira', 'Sabado');
		//$data = date('Y-m-d');
		$data = $dataAtual;
		$dia_numero = date('w', strtotime($data));
		//echo $diasemana1[$dia_numero];
		$diad = $diasemana1[$dia_numero];



        //-----------
        $sql1 = "DELETE FROM tbcompromissos WHERE data='$dataAtual' and hora ='$id' ";
        $sql1 = $this->db->query($sql1) ;

               // echo "<script>    window.alert('$dataAtual   $id')   </script>";
        //-----------
		

		$sql = "insert into tbcompromissos set cor= '$cor' , compromisso = '$compromisso', data='$dataAtual', 
		diasemana='$diad' , hora ='$id' ";


		$sql = $this->db->query($sql) ;

		if ($sql->rowCount()>0)
		{
		    $array = $sql->fetch();

		}

        //echo "<script>    window.alert('salvo com sucessso!')   </script>";
        echo "<meta http-equiv='refresh' content=0;url=". BASE_URL . "compromisso>";    	



	}



}

