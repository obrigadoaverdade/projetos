<?php

class homeController extends controller{

	public function index(){

        $dados = array();

	    echo "<meta http-equiv='refresh' content=0;url=". BASE_URL . "compromisso>";    	

	}


	
}