<?php

class compromissoController extends controller
{


	public function index()
	{
$diasemana1 = array('Domingo', '2 feira', '3 feira', '4 feira', '5 feira', '6 feira', 'Sabado');
    	$data = date('Y-m-d');
		$dia_numero = date('w', strtotime($data));
		$diad = $diasemana1[$dia_numero];
     	$dados = array();

			$comp = new Compromisso();
			$d = "";
			//$d = $comp->getSemana("2019-01-14");
			$d = $comp->getSemana(date('Y-m-d'));
            $e = $comp->getComp(date('Y-m-d'), $diad, "05:20:20");         
		    $this->loadTemplate('compromisso', $dados);

	}

	public function salvar($id,$compromisso,$dataAtual, $cor)
	{
		if (isset($id) &&(!empty($id)))
		{
		$id = addslashes($id);
		$compromisso = addslashes($compromisso);
		$dataAtual = addslashes($dataAtual);
		$cor = addslashes($cor);
		/*echo "Valor recebido" . $id;
		echo "Valor recebido" . $compromisso;
		echo "Valor recebido" . $dataAtual;
		*/

		if ($compromisso == "-")
			$cor = "#ffffff";

		$comp = new Compromisso();
		$comp->salvando($id, $compromisso, $dataAtual, $cor);

        //echo "<script>alert(' $cor ')</script>";
		//echo '<script>alert(' + "'" . $cor . "'" + ')</script>';
		//echo "'". $corhora . "';";


		}



	}

	
}