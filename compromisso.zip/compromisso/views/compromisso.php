<!DOCTYPE html>
  <head>

  <title>Compromissos</title>
<link rel ="stylesheet" href="<?php echo BASE_URL ?>assets/css/template.css"   />
    
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <link rel ="stylesheet" href="<?php echo BASE_URL ?>assets/css/style.css"   />
    
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

   <script type="text/javascript" src="<?php echo BASE_URL ?>assets/js/jquery-3.3.1.min.js" /></scipt>
   <script type="text/javascript" src="<?php echo BASE_URL ?>assets/js/bootstrap.min.js" /></script>
   <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
  </head>

<?php date_default_timezone_set('America/Sao_Paulo'); ?>

  </head>
  <body>

    
  

<!--
      echo '<script>
              var base = ' ;
      echo "'" .$texto ."'" ;
      echo '; ';
      echo 'alert(base);  
        </script>';
!-->      

<?php
function getDiaSemana($dataAtual)
{
  $diasemana1 = array('Domingo', '2 feira', '3 feira', '4 feira', '5 feira', '6 feira', 'Sabado');
  $data = $dataAtual;
  $dia_numero = date('w', strtotime($data));
  $diad = $diasemana1[$dia_numero];
  return $diad;
}
?>


<?php
function retSemana($dia)
{
    switch ($dia) 
    {
      case 0: $semana = "Domingo"; break;
      case 1: $semana = "2 feira"; break;
      case 2: $semana = "3 feira"; break;
      case 3: $semana = "4 feira"; break;
      case 4: $semana = "5 feira"; break;
      case 5: $semana = "6 feira"; break;
      case 6: $semana = "Sabado";  break;     
      default: $semana = "Domingo"; break;
    }
    return $semana;
}
?>

<?php
function dataBarra ($datainc, $incremento)
{
     $data = $datainc; 
     $nova = date('d/m/Y', strtotime("+$incremento days",strtotime($data))); 
     return $nova;
}
?>


<?php
function novadata ($datainc, $incremento)
{
     $data = $datainc; 
     $nova = date('Y-m-d', strtotime("+$incremento days",strtotime($data))); 
     return $nova;
}
?>

<?php
function ajustadata ($datainc, $incremento, $op)
{
     $data = $datainc; 
     $nova = date('Y-m-d', strtotime("$op$incremento days",strtotime($data))); 
     return $nova;
}
?>


<?php 
function buscaDomingo($dataAtual)
{
  //busca o domingo mais próximo
  $diasemana1 = array('Domingo', '2 feira', '3 feira', '4 feira', '5 feira', '6 feira', 'Sabado');
  $data = $dataAtual;
  $dia_numero = date('w', strtotime($data));
  $diad = $diasemana1[$dia_numero];

  switch ($diad) 
  {
  case 'Domingo':
      $domingodasemana = $dataAtual;  
    break;

  case '2 feira':
      $domingodasemana = ajustadata($dataAtual, 1, "-");  
    break;

  case '3 feira':
      $domingodasemana = ajustadata($dataAtual, 2, "-");  
    break;

  case '4 feira':
      $domingodasemana = ajustadata($dataAtual, 3, "-");  
    break;

  case '5 feira':
      $domingodasemana = ajustadata($dataAtual, 4, "-");  
    break;

  case '6 feira':
      $domingodasemana = ajustadata($dataAtual, 5, "-");  
    break;

  case 'Sabado':
      $domingodasemana = ajustadata($dataAtual, 6, "-");  
    break;

  default:
    # code...
    break;
    }
    return $domingodasemana;
}

//echo buscaDomingo("2019-01-15");


?>

<script>
     function novaData1(d, n) 
     {
        //d = data no formato dia+mes+ano; n = numero de dias a somar
     if (d != '') 
     {
        //2019-01-13
        var partes = d.split('-');
        var dia = partes[2];
        var mes = partes[1];
        var ano = partes[0];
        dia = dia + '';
        mes = mes + '';
        ano = ano + '';
      
        r = new Date(ano, mes, dia);
        r.setDate(r.getDate() + parseInt(n));
//        return (r.getDate() + '-' + r.getMonth() + '-' + r.getFullYear());
           return (r.getFullYear() + '-' +  r.getMonth() + '-' + r.getDate() );
      }
     }
</script>



<?php
//unset ($_COOKIE["dataSetada"]);
if (!isset($_COOKIE["dataSetada"]))
{
  $_COOKIE["dataSetada"] = buscaDomingo(date('Y-m-d'));
}
?>



<div>Domingo foi: </div>

<input id="dateini" type="date" onchange=mudaData() value=<?php echo buscaDomingo($_COOKIE["dataSetada"]) ?> 



<!--$dataInicial="2019-01-13"; -->

<script>
  function mudaData()
  {
    var dat = document.getElementById("dateini");      
    setData(dat.value);
    location.reload(); 
  }

  function setData(v) 
   {
      document.cookie = "dataSetada" + "=" + v ;

//    alert(document.cookie);
   }


</script>

<?php 
   $d=""; 
   $e=""; 
   global $dataInicial, $contador, $labelBotao, $contaLabelBotao;
   $contador = 1;

   $labelBotao = 4;
   
   $contaLabelBotao=-1;

   //$dataInicial=buscaDomingo(date('Y-m-d')); 
   $dataInicial=buscaDomingo($_COOKIE["dataSetada"]); 
   //echo $dataInicial;

   global $co; 
   $co = new Compromisso(); 
?>

<?php
//unset ($_COOKIE["corBotao"]);
if (!isset($_COOKIE["corBotao"]))
{
  $_COOKIE["corBotao"] = "#FFD700";
}
?>

<input type="color" id="caixaCor" onchange=mudou() value=<?php echo $_COOKIE["corBotao"]; ?>>
  
<div>Hoje é dia: <?php echo (date ("d/m/Y")) ." | ". getDiaSemana(date('d-m-Y')); ?> </div>
   
<script>
  function mudou()
  {
    var cx = document.getElementById("caixaCor");      
    //document.cookie="corBotao='" + cx.value +   "'";
    setCor(cx.value);
    //document.cookie="corBotao=#cccccc";

   // alert(cx.value);
   // alert(document.cookie);  

  }

   function setCor(v) 
   {
      document.cookie = "corBotao" + "=" + v ;

//    alert(document.cookie);
   }

  
</script>


<?php
function  getconteudo($xy, $dia, $hora)
{
    global $co, $dataInicial, $contador, $labelBotao, $contaLabelBotao;
    $emp = "";

    
    $semana = retSemana($dia);

    $d = $co->getComp(novadata($dataInicial, $dia), $semana, "$hora:00", "$hora:30");   
    if (isset($d['compromisso'] ))
    $emp = $d['compromisso'] ;
    else
      $emp = '';
        
    if (isset($d['cor'] ))       
    $corBD =  '#'. $d["cor"];
  else
    $corBD = '';


   // echo $corBD;

/*
   echo "$emp";
   echo novadata($dataInicial, $dia);
   echo "<br>";
   echo "$semana";
   echo "<br>";
*/
   $cont = $contador; 

   

   echo '<script>
    function salvar' ;
    echo "" . $cont . " ()";
    echo '
    {  
       var hora1 = ';
       echo "'". $hora . "';";
       echo '

       
       var xcomp = ';
       echo "'". $xy . "';";
       
       echo 'var el1 = document.getElementById( xcomp );     
             var el2 = document.getElementById("dateini");               
             var Data2 = novaData1(el2.value, '. $dia.');  

             var caixaCorNova = document.getElementById("caixaCor");         

             if(el1.value == "")
             {
              el1.value = "-";
             }
             

             var str = caixaCorNova.value;
             var res = str.substr(1, 7);

             var base = '; 

       echo "'". BASE_URL ."' ;";

       echo 'window.location.href =';
       echo 'base + "compromisso/salvar/'. $hora . ':00/"' ;
        
       echo '+ el1.value + "/" +  Data2  + "/" + res ';   
       //echo '+ el1.value + "/" +  Data2   ';   
       echo ';
       
     }
        </script>';


  echo "<td> <div  style='background-color:$corBD ; width:160px; overflow:auto; '>
       <input type='text' style='background-color:$corBD ; width: 128px' id='$xy' name='$xy' value='$emp' "; 
     echo ' > ';         
  

  $contaLabelBotao++;
  
  if($contaLabelBotao%7==0)
  ++$labelBotao;

  
  
  echo "<button onclick='salvar$cont();' style='width: 30px; height: 25px; padding-left:4px ; float: right;'> $labelBotao</button></div> </td>";


  ++$contador;
   }

?>

  
<!-- '$corBD' -->


<table class="table table-striped table-bordered table-hover">
  

 <tr>
    <th colspan="8"><center>Planejamento Semanal</center></th>
 </tr>







 <tr>
     <th width="100">Horarios</th>
<th style="background-color: red; "><center><div> <?php  echo dataBarra($dataInicial, 0); echo " - Domingo";  ?></div></center></th>
<th style="background-color: yellow; "><center><div> <?php  echo dataBarra($dataInicial, 1); echo " - 2 Feira";  ?></div></center></th>    
<th style="background-color: orange; "><center><div> <?php  echo dataBarra($dataInicial, 2); echo " - 3 Feira";  ?></div></center></th>    
<th style="background-color: green; "><center><div> <?php  echo dataBarra($dataInicial, 3); echo " - 4 Feira";  ?></div></center></th>    
<th style="background-color: blue; "><center><div> <?php  echo dataBarra($dataInicial, 4); echo " - 5 Feira";  ?></div></center></th>        
<th style="background-color: pink; "><center><div> <?php  echo dataBarra($dataInicial, 5); echo " - 6 Feira";  ?></div></center></th>        
<th style="background-color: #d51313; "><center><div> <?php  echo dataBarra($dataInicial, 6); echo " - Sabado";  ?></div></center></th>        

 </tr>

<tr>
    <td width="100"><div  style='width:80px; overflow:auto;'>05:00-05:59</div></td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a1",0,"05"); ?>
    <?php getconteudo("b1",1,"05"); ?>
    <?php getconteudo("c1",2,"05"); ?>
    <?php getconteudo("d1",3,"05"); ?>
    <?php getconteudo("e1",4,"05"); ?>
    <?php getconteudo("f1",5,"05"); ?>
    <?php getconteudo("g1",6,"05"); ?>
    <!------------------------------------------------------------------------------------->
</tr>


<tr>
    <td width="100">06:00-06:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a2",0,"06"); ?>
    <?php getconteudo("b2",1,"06"); ?>
    <?php getconteudo("c2",2,"06"); ?>
    <?php getconteudo("d2",3,"06"); ?>
    <?php getconteudo("e2",4,"06"); ?>
    <?php getconteudo("f2",5,"06"); ?>
    <?php getconteudo("g2",6,"06"); ?>
    <!------------------------------------------------------------------------------------->
</tr>


<tr>
    <td width="100">07:00-07:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a3",0,"07"); ?>
    <?php getconteudo("b3",1,"07"); ?>
    <?php getconteudo("c3",2,"07"); ?>
    <?php getconteudo("d3",3,"07"); ?>
    <?php getconteudo("e3",4,"07"); ?>
    <?php getconteudo("f3",5,"07"); ?>
    <?php getconteudo("g3",6,"07"); ?>
    <!------------------------------------------------------------------------------------->
</tr>

<tr>
    <td width="100">08:00-08:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a4",0,"08"); ?>
    <?php getconteudo("b4",1,"08"); ?>
    <?php getconteudo("c4",2,"08"); ?>
    <?php getconteudo("d4",3,"08"); ?>
    <?php getconteudo("e4",4,"08"); ?>
    <?php getconteudo("f4",5,"08"); ?>
    <?php getconteudo("g4",6,"08"); ?>
    <!------------------------------------------------------------------------------------->
</tr>


<tr>
    <td width="100">09:00-09:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a5",0,"09"); ?>
    <?php getconteudo("b5",1,"09"); ?>
    <?php getconteudo("c5",2,"09"); ?>
    <?php getconteudo("d5",3,"09"); ?>
    <?php getconteudo("e5",4,"09"); ?>
    <?php getconteudo("f5",5,"09"); ?>
    <?php getconteudo("g5",6,"09"); ?>
    <!------------------------------------------------------------------------------------->
</tr>


<tr>
    <td width="100">10:00-10:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a6",0,"10"); ?>
    <?php getconteudo("b6",1,"10"); ?>
    <?php getconteudo("c6",2,"10"); ?>
    <?php getconteudo("d6",3,"10"); ?>
    <?php getconteudo("e6",4,"10"); ?>
    <?php getconteudo("f6",5,"10"); ?>
    <?php getconteudo("g6",6,"10"); ?>
    <!------------------------------------------------------------------------------------->
</tr>


<tr>
    <td width="100">11:00-11:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a7",0,"11"); ?>
    <?php getconteudo("b7",1,"11"); ?>
    <?php getconteudo("c7",2,"11"); ?>
    <?php getconteudo("d7",3,"11"); ?>
    <?php getconteudo("e7",4,"11"); ?>
    <?php getconteudo("f7",5,"11"); ?>
    <?php getconteudo("g7",6,"11"); ?>
    <!------------------------------------------------------------------------------------->
</tr>


<tr>
    <td width="100">12:00-12:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a8",0,"12"); ?>
    <?php getconteudo("b8",1,"12"); ?>
    <?php getconteudo("c8",2,"12"); ?>
    <?php getconteudo("d8",3,"12"); ?>
    <?php getconteudo("e8",4,"12"); ?>
    <?php getconteudo("f8",5,"12"); ?>
    <?php getconteudo("g8",6,"12"); ?>
    <!------------------------------------------------------------------------------------->
</tr>


<tr>
    <td width="100">13:00-13:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a9",0,"13"); ?>
    <?php getconteudo("b9",1,"13"); ?>
    <?php getconteudo("c9",2,"13"); ?>
    <?php getconteudo("d9",3,"13"); ?>
    <?php getconteudo("e9",4,"13"); ?>
    <?php getconteudo("f9",5,"13"); ?>
    <?php getconteudo("g9",6,"13"); ?>
    <!------------------------------------------------------------------------------------->
</tr>



<tr>
    <td width="100">14:00-14:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a10",0,"14"); ?>
    <?php getconteudo("b10",1,"14"); ?>
    <?php getconteudo("c10",2,"14"); ?>
    <?php getconteudo("d10",3,"14"); ?>
    <?php getconteudo("e10",4,"14"); ?>
    <?php getconteudo("f10",5,"14"); ?>
    <?php getconteudo("g10",6,"14"); ?>
    <!------------------------------------------------------------------------------------->
</tr>

<tr>
    <td width="100">15:00-15:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a11",0,"15"); ?>
    <?php getconteudo("b11",1,"15"); ?>
    <?php getconteudo("c11",2,"15"); ?>
    <?php getconteudo("d11",3,"15"); ?>
    <?php getconteudo("e11",4,"15"); ?>
    <?php getconteudo("f11",5,"15"); ?>
    <?php getconteudo("g11",6,"15"); ?>
    <!------------------------------------------------------------------------------------->
</tr>


<tr>
    <td width="100">16:00-16:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a12",0,"16"); ?>
    <?php getconteudo("b12",1,"16"); ?>
    <?php getconteudo("c12",2,"16"); ?>
    <?php getconteudo("d12",3,"16"); ?>
    <?php getconteudo("e12",4,"16"); ?>
    <?php getconteudo("f12",5,"16"); ?>
    <?php getconteudo("g12",6,"16"); ?>
    <!------------------------------------------------------------------------------------->
</tr>


<tr>
    <td width="100">17:00-17:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a13",0,"17"); ?>
    <?php getconteudo("b13",1,"17"); ?>
    <?php getconteudo("c13",2,"17"); ?>
    <?php getconteudo("d13",3,"17"); ?>
    <?php getconteudo("e13",4,"17"); ?>
    <?php getconteudo("f13",5,"17"); ?>
    <?php getconteudo("g13",6,"17"); ?>
    <!------------------------------------------------------------------------------------->
</tr>


<tr>
    <td width="100">18:00-18:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a14",0,"18"); ?>
    <?php getconteudo("b14",1,"18"); ?>
    <?php getconteudo("c14",2,"18"); ?>
    <?php getconteudo("d14",3,"18"); ?>
    <?php getconteudo("e14",4,"18"); ?>
    <?php getconteudo("f14",5,"18"); ?>
    <?php getconteudo("g14",6,"18"); ?>
    <!------------------------------------------------------------------------------------->
</tr>


<tr>
    <td width="100">19:00-19:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a15",0,"19"); ?>
    <?php getconteudo("b15",1,"19"); ?>
    <?php getconteudo("c15",2,"19"); ?>
    <?php getconteudo("d15",3,"19"); ?>
    <?php getconteudo("e15",4,"19"); ?>
    <?php getconteudo("f15",5,"19"); ?>
    <?php getconteudo("g15",6,"19"); ?>
    <!------------------------------------------------------------------------------------->
</tr>

<tr>
    <td width="100">20:00-20:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a16",0,"20"); ?>
    <?php getconteudo("b16",1,"20"); ?>
    <?php getconteudo("c16",2,"20"); ?>
    <?php getconteudo("d16",3,"20"); ?>
    <?php getconteudo("e16",4,"20"); ?>
    <?php getconteudo("f16",5,"20"); ?>
    <?php getconteudo("g16",6,"20"); ?>
    <!------------------------------------------------------------------------------------->
</tr>


<tr>
    <td width="100">21:00-21:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a17",0,"21"); ?>
    <?php getconteudo("b17",1,"21"); ?>
    <?php getconteudo("c17",2,"21"); ?>
    <?php getconteudo("d17",3,"21"); ?>
    <?php getconteudo("e17",4,"21"); ?>
    <?php getconteudo("f17",5,"21"); ?>
    <?php getconteudo("g17",6,"21"); ?>
    <!------------------------------------------------------------------------------------->
</tr>

<tr>
    <td width="100">22:00-22:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a18",0,"22"); ?>
    <?php getconteudo("b18",1,"22"); ?>
    <?php getconteudo("c18",2,"22"); ?>
    <?php getconteudo("d18",3,"22"); ?>
    <?php getconteudo("e18",4,"22"); ?>
    <?php getconteudo("f18",5,"22"); ?>
    <?php getconteudo("g18",6,"22"); ?>
    <!------------------------------------------------------------------------------------->
</tr>


<tr>
    <td width="100">23:00-23:59</td>
               <!-- //xy, dia semana, hora -->
    <?php getconteudo("a19",0,"23"); ?>
    <?php getconteudo("b19",1,"23"); ?>
    <?php getconteudo("c19",2,"23"); ?>
    <?php getconteudo("d19",3,"23"); ?>
    <?php getconteudo("e19",4,"23"); ?>
    <?php getconteudo("f19",5,"23"); ?>
    <?php getconteudo("g19",6,"23"); ?>
    <!------------------------------------------------------------------------------------->
</tr>

</table>


   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script src="<?php echo BASE_URL ?>assets/js/bootstrap.min.js"></script>  
  </body>
</html>